package guildautogg.modid.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.Minecraft;

import java.util.Random;

public class GuildAutoGGClient implements ClientModInitializer {

    private long lastTriggerTime = 0;
    private String lastWord = "";

    private final String[] GG_WORDS = {"gg", "ggs", "w", "nice"};
    private final Random random = new Random();

    // EASY ADDITIONS: Each entry is a set of keywords that MUST ALL be in the chat message to trigger.
    private static final String[][] TRIGGER_RULES = {
            {"➜"},
            {"!", "(+"},
            {"WOW!", "Dye"},
            {"TROPHY", "You caught"},
            {"OFFER ACCEPTED", ","},
            {"[SkyHanni]", "("},
            {"You Supercrafted", "!"}
            // To add a single phrase requirement, use: {"Phrase"}
            // To add a multiple phrase requirement, use: {"Phrase 1", "Phrase 2"}
    };

    @Override
    public void onInitializeClient() {
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            handleMessage(message.getString());
        });

        ClientReceiveMessageEvents.CHAT.register((message, signedMessage, sender, params, receptionTimestamp) -> {
            handleMessage(message.getString());
        });
    }

    private void handleMessage(String text) {
        // Step 1: Rapid check to make sure it's even a trigger message
        if (!isGGTrigger(text)) {
            return;
        }

        Minecraft client = Minecraft.getInstance();
        if (client.player == null) {
            return;
        }

        int colonIndex = text.indexOf(":");
        if (colonIndex != -1) {
            // Self-Check
            String senderInfo = text.substring(0, colonIndex);
            String myName = client.player.getName().getString();

            if (senderInfo.contains(myName)) {
                return;
            }

            // Length Check
            String actualMessage = text.substring(colonIndex + 1).trim();
            if (actualMessage.length() < 11) {
                return;
            }
        } else {
            return;
        }

        // Cooldown Check (4 seconds)
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastTriggerTime < 4000) {
            return;
        }

        String messageToSend;

        if (random.nextInt(1000) == 0) {
            messageToSend = "Not that impressive";
        } else {
            String chosenWord;
            do {
                chosenWord = GG_WORDS[random.nextInt(GG_WORDS.length)];
            } while (chosenWord.equals(lastWord));

            lastWord = chosenWord;
            messageToSend = chosenWord;
        }

        if (client.getConnection() != null) {
            client.getConnection().sendCommand("gc " + messageToSend);
            lastTriggerTime = currentTime;
        }
    }

    /**
     * Checks if the message is in Guild chat and matches at least one rule set in TRIGGER_RULES.
     */
    private boolean isGGTrigger(String text) {
        if (!text.contains("Guild >")) {
            return false;
        }

        for (String[] ruleSet : TRIGGER_RULES) {
            boolean allKeywordsMatch = true;

            for (String keyword : ruleSet) {
                if (!text.contains(keyword)) {
                    allKeywordsMatch = false;
                    break; // Skip to the next rule set if any required keyword is missing
                }
            }

            if (allKeywordsMatch) {
                return true; // Match found!
            }
        }

        return false;
    }
}